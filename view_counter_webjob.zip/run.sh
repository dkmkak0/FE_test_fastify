#!/bin/bash
npm install
node src/workers/view_counter.js